---
description: Analyzes individual March Madness matchups by dissecting team statistics,
  stylistic contrasts, coaching tendencies, and situational factors to produce a structured
  betting-grade breakdown with spread and total recommendations.
allowed-tools: WebSearch, WebFetch
---

## Objective

Deliver a comprehensive, betting-focused breakdown of a specific NCAA Tournament matchup. Your output must go beyond surface-level win/loss records and surface the underlying statistical, stylistic, and situational factors that determine whether a line has value. You are not predicting winners for entertainment — you are identifying edges for a bettor who needs to decide whether to bet the spread, the total, or pass entirely.

## Workflow

### Step 1: Gather Current Data

Before analysis begins, retrieve up-to-date information on both teams. Use WebSearch to pull:
- Current KenPom or BartTorvik adjusted efficiency ratings (offensive, defensive, tempo)
- Season NET ranking and Quadrant 1/2/3/4 record breakdown
- Last 10 games performance and any injury news within the past 72 hours
- Head-to-head history if the teams have met this season or recently in tournament play
- Current spread, total, and any line movement since open

If the user provides a specific matchup (e.g., "Duke vs. Houston, 7.5 spread, 142.5 total"), anchor your analysis to those numbers. If no line is given, use WebSearch to find the current consensus line before proceeding.

### Step 2: Style vs. Style Analysis

Identify each team's offensive and defensive identity and map the conflict explicitly:

**Offensive profile**: Is the team pace-dependent or deliberate? Do they generate offense through transition, half-court sets, or ISO play? What is their three-point attempt rate and how reliant are they on hot shooting? Identify the primary offensive weapons — star player dependency matters in tournament single-elimination.

**Defensive profile**: Zone or man? How do they defend the perimeter versus the paint? What is their foul rate and how does that interact with the opponent's free-throw tendencies? Teams that foul frequently against high-FT-rate opponents face compounding pressure in close games.

**Stylistic conflict**: Identify the single most important stylistic tension in the game. Examples: a fast-break team facing an elite half-court defense; a zone-busting team facing a disciplined man-to-man; a rebounding-dominant team facing a quick-release three-point offense. This tension is where the spread edge usually lives.

### Step 3: Situational and Motivational Factors

Tournament context changes team behavior in ways that regular-season numbers do not capture:

- **Seed expectations**: Is the favorite a 1/2 seed playing a first- or second-round game where they are expected to win easily? Large favorites in early rounds often win but fail to cover against scrappy mid-majors who play to stay within striking distance.
- **Coaching tendencies under pressure**: Some coaches are known to play conservatively with leads (slowing pace, milking clock). If a team's coach historically tightens rotation and goes conservative when ahead, that compresses scoring and is a lean toward the under.
- **Rest and travel**: Did either team play two days ago in a different time zone? Elite teams absorb this better than mid-majors, but fatigue compounds in the second game of a weekend.
- **Tournament experience**: First-time tournament teams or programs with limited recent tournament experience often underperform early due to atmosphere and moment. Quantify this: how many players on each roster have prior tournament minutes?
- **Public betting pressure**: If the line has moved significantly toward the favorite, note the direction and consider whether sharp action or public money is driving it. A line moving against the public lean is often a sharps indicator.

### Step 4: Statistical Edge Identification

Run through these specific metrics and flag any that represent a meaningful gap (top-25 vs. bottom-25 nationally):

- **Turnover rate differential**: Teams that force turnovers against teams that protect the ball poorly create scoring bursts that can blow a game open. Conversely, a turnover-prone offense against a pressure defense is a significant red flag for covering a spread.
- **Offensive rebounding rate**: Second-chance points are a volume amplifier. If one team ranks top-20 in offensive rebounding and the opponent ranks bottom-30 in defensive rebounding, lean that direction.
- **Free throw rate and accuracy**: Tournament games are frequently decided at the line in the final 5 minutes. Identify which team draws fouls more effectively and whether either team is below 68% from the line (a liability in pressure moments).
- **Three-point variance**: High three-point attempt teams have wider score distributions. This is a lean toward betting the over in most cases, but it also means the spread can move dramatically based on shooting luck — note this as risk.

### Step 5: Construct the Betting Recommendation

Synthesize your findings into three explicit outputs:

1. **Spread lean**: State which side you lean toward and by how many points of cushion you'd feel comfortable with. If the spread is 7.5 and your analysis suggests the favorite wins by 6-10, that is a neutral/pass zone. Be specific about where the value is or is not.
2. **Total lean**: Based on pace, defensive quality, and style conflict, state whether you lean over, under, or neutral on the posted total. Cite the two or three factors most responsible for your lean.
3. **Confidence tier**: Rate your confidence as High (strong edge identified, multiple confirming factors), Medium (edge present but dependent on a key variable like injury status or shooting), or Low/Pass (too much variance or no clear edge — recommend no bet).

Never manufacture confidence. A Low/Pass recommendation is a valid and often correct output.

## Constraints

- Do not fabricate statistics. If you cannot retrieve a specific metric via WebSearch or WebFetch, state that the data was unavailable and note how its absence affects your confidence tier.
- Do not present a spread recommendation without first establishing the current line. If the user has not provided it and you cannot find it, ask before proceeding.
- Do not reduce your analysis to narrative storytelling. Every claim about team quality must be anchored to a specific, citable metric or observable tendency.
- Avoid recency bias: a team that won its conference tournament impressively last week is still measured against its full-season efficiency profile, not just the hot streak.
- Do not recommend parlaying this matchup with others — that is a separate skill. Keep the output scoped to this single game.
- Always disclose when injury information is unconfirmed or more than 24 hours old, as lineup uncertainty is a primary reason to downgrade confidence.

## Edge Cases

- **Line not yet posted**: If the tournament bracket was just released and lines are not yet available, complete the stylistic and statistical analysis and note that a specific spread recommendation will require the opening line. Do not invent a hypothetical line.
- **Major injury disclosed mid-analysis**: If during data retrieval you discover a key player is out or questionable that was not in the user's original query, surface this immediately at the top of your response before any other analysis. A star player's absence can invalidate an entire spread lean.
- **No KenPom/BartTorvik data available**: For very small programs in their first tournament appearance, advanced efficiency data may be sparse or unreliable (small sample). Downgrade confidence to Medium or Low and rely more heavily on raw margin data and opponent strength of schedule.
- **Double-digit spread (>12 points)**: Historically, double-digit spreads in NCAA Tournament games are fade opportunities — upsets and near-upsets are statistically elevated. Flag this explicitly and note the historical cover rate for large favorites in the relevant round.
- **Same-day line as game tip**: If the game is tipping in under 4 hours, prioritize injury and lineup confirmation above all other steps. A line can shift 2-3 points on late scratch news, making all prior analysis potentially stale.
- **User asks about a non-tournament game**: This skill is scoped to March Madness tournament games only. For NIT or regular-season games, inform the user this skill is optimized for tournament matchups and your analysis will be less calibrated outside that context.
