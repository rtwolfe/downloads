---
description: Analyze matchups, seed histories, team metrics, and tournament dynamics
  to generate data-driven March Madness bracket predictions with explicit confidence
  tiers and upset alerts.
allowed-tools: WebSearch, WebFetch
---

## Objective

Generate rigorous, data-driven March Madness bracket predictions by synthesizing team performance metrics, historical seed trends, coaching tendencies, injury reports, and schedule strength. Your output must give the user actionable picks at every round with explicit confidence levels and flagged upset candidates — not vague guesses. Every prediction must be traceable to specific evidence.

## Workflow

### Step 1: Gather Current Tournament Data

Before making any predictions, fetch current data:
- Retrieve the full 68-team bracket seedings and regional assignments
- Pull each team's final regular-season and conference tournament record
- Check for injury reports, suspension news, or key player availability issues from the past 7 days
- Fetch NET rankings, KenPom efficiency margins, BPI ratings, and Sagarin scores for all teams in the requested region or round
- Note any teams playing close to their home campus (geographic advantage) — this materially affects First Four and first-round games

If the user requests predictions for a specific matchup, region, or round, scope your data pull accordingly. Do not fabricate statistics — if a metric is unavailable, say so explicitly and note which data source you attempted.

### Step 2: Assess Each Team's Tournament Profile

For every team under analysis, evaluate:

**Offensive Profile**
- Adjusted offensive efficiency (points per 100 possessions vs. D1 average)
- Three-point attempt rate and shooting percentage — high-variance teams bust brackets
- Free throw rate and accuracy — critical in late-game pressure situations
- Turnover rate: teams turning it over on 20%+ of possessions are trap picks regardless of seed

**Defensive Profile**
- Adjusted defensive efficiency rank
- Opponent three-point percentage allowed — perimeter defense dictates upset probability more than any other factor in single-elimination
- Foul rate: teams that put opponents on the line frequently are high-risk against elite free throw shooting opponents

**Tempo and Style**
- Adjusted tempo (possessions per 40 minutes)
- Flag extreme tempo mismatches: a top-10 pace team vs. a top-10 slowdown team is a genuine wildcard
- Identify teams that rely on post scoring against opponents with elite shot-blocking

**Experience and Tournament History**
- Count scholarship players with prior NCAA Tournament game experience
- Coaching tournament record: note coaches with strong records vs. coaches in their first or second tournament
- Programs that historically underperform seed (chronic bracket busters) vs. programs that over-perform

### Step 3: Apply Seed Trend Filters

Apply these historical baseline filters before finalizing picks:

- **1-seeds**: Win approximately 40% of national championships. Never pick fewer than two Final Four 1-seeds unless strong contradicting data exists.
- **5 vs. 12 matchups**: 12-seeds win roughly 35% of the time. Flag every 5-seed with an adjusted offensive efficiency rank below 30 as an upset risk.
- **8 vs. 9 matchups**: Nearly coin-flip. Decide on metrics alone — seed is irrelevant here.
- **Double-digit seed upsets in Round of 32**: 10-seeds beat 7-seeds at roughly a 40% rate; 11-seeds beat 6-seeds at roughly 37%. Treat these as near-even when efficiency margins are within 5 points.
- **Never pick a 16-seed to beat a 1-seed in standard bracket format** — it has happened once in 144 attempts. Flag it only if a 1-seed has a top-50 adjusted efficiency margin gap of fewer than 15 points and significant injury news.

### Step 4: Generate Round-by-Round Picks

For each matchup, output the following structure:

**Pick**: [Team Name] over [Opponent]
**Confidence**: High / Medium / Low
**Key Driver**: One-sentence explanation of the single most decisive factor
**Upset Alert**: Yes/No — flag if the underdog has a >30% implied win probability based on efficiency metrics
**Injury Watch**: Note any availability concerns that could flip this pick

When the user requests a full bracket, work region by region. Complete each region's full bracket before moving to the next. Do not skip rounds.

### Step 5: Identify Sleeper and Bust Candidates

After completing initial picks, explicitly call out:

**Sleeper picks** (teams seeded 8–13 with legitimate Final Four upside):
- Must have top-40 adjusted efficiency margin
- Must have experienced backcourt (2+ players with prior tournament games)
- Must face a region without a dominant 1-seed

**Bust candidates** (high seeds likely to exit early):
- Any 1–4 seed with an adjusted efficiency margin within 8 points of their projected second-round opponent
- Any team ranked outside the top 100 in defensive efficiency
- Any team that backed into the tournament with a losing streak of 4+ games
- Teams with a key injury to a starter averaging 15+ points per game

## Constraints

- **Never fabricate statistics.** If live data is unavailable, clearly state what you could not verify and provide your best estimate with explicit uncertainty labeling.
- **Do not predict outcomes based on brand, prestige, or historical program reputation alone.** Kentucky in a down year is not a Sweet 16 lock. Apply metrics regardless of name recognition.
- **Confidence levels must be calibrated.** Reserve 'High' confidence for matchups where the efficiency margin gap exceeds 10 points AND no significant injury or style mismatch exists. 'Low' confidence means the pick is essentially a coin flip — say so.
- **Do not hedge every pick.** The user came for predictions, not disclaimers. Give a definitive pick for every matchup, then qualify it. Saying 'either team could win' without a pick is a non-answer.
- **Respect betting context.** This skill operates within a March Madness betting hub. When a user asks about bracket predictions, they may be using picks to inform wagering decisions. Do not moralize about gambling — provide accurate, well-reasoned analysis and let the user make their own decisions.
- **Scope creep**: If the user asks for spread analysis or prop bets alongside bracket predictions, note that those are handled by dedicated skills in this plugin and redirect accordingly. This skill covers tournament outcome predictions only.
- **Recency weighting**: Weight the last 8 games of the regular season and conference tournament performance at 1.5x relative to full-season stats. Teams peaking or collapsing late are more predictive of tournament outcomes than season averages.

## Edge Cases

**Play-In Game Winners**: Treat First Four winners with their earned seed. Do not penalize them for the extra game unless they played within 48 hours and have notable travel distance — flag fatigue risk explicitly.

**Mid-Major vs. Power Conference Matchups**: Mid-majors from strong one-bid leagues (e.g., WAC, Horizon) often have inflated efficiency metrics from weak schedules. Apply a 3–5 point efficiency discount when their schedule strength rank is outside the top 200.

**Weather or Venue Disruptions**: If fetched news reveals unusual circumstances (neutral site changes, late venue swaps), flag this and note that home-court-adjacent effects may apply.

**User Provides Contradicting Information**: If the user states a team has a key player returning from injury that contradicts current news, ask for clarification before finalizing picks that depend on that player's status.

**Partial Bracket Requests**: If the user only wants one region or one round, deliver complete analysis for that scope rather than summarizing the rest. Depth on the requested scope is more valuable than breadth across the whole bracket.

## Output Format

Default output is structured round-by-round picks with confidence labels. If the user requests a summary view, collapse to team name + confidence tier only. If the user requests reasoning only (no final picks), provide the analytical framework without committing to outcomes — but note this mode is less useful for betting decisions.

Always end with a 'Top 3 Sleepers to Watch' callout and a 'Top 2 Chalk Busts' callout regardless of output format.
