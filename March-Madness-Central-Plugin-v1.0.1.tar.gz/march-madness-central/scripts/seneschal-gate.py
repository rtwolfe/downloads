#!/usr/bin/env python3
"""SENESCHAL governance gate for Cowork plugins.

Hook script that bridges Claude Code → SENESCHAL runtime enforcement.
Exit 0 = allow tool execution.  Exit 1 = block tool execution.
Uses only Python stdlib — no pip dependencies.
"""
import hashlib
import hmac
import json
import os
import stat
import sys
import tempfile
import uuid
from datetime import datetime, timezone
from pathlib import Path
from urllib.error import URLError
from urllib.parse import urlparse
from urllib.request import Request, urlopen

# ── Constants ──────────────────────────────────────────────────────

PLUGIN_ROOT = os.environ.get("CLAUDE_PLUGIN_ROOT", ".")
PLUGIN_DATA = os.environ.get("CLAUDE_PLUGIN_DATA", "/tmp")
SESSION_ID = os.environ.get("CLAUDE_SESSION_ID", str(uuid.uuid4()))
CASTELLAN_DIR = os.path.join(PLUGIN_ROOT, ".castellan")
HTTP_TIMEOUT = 3  # seconds — hooks must be fast

# Session file keyed to session ID — prevents cross-session poisoning
_SESSION_DIR = os.path.join(PLUGIN_DATA, ".seneschal_sessions")
_SESSION_FILENAME = f"session-{hashlib.sha256(SESSION_ID.encode()).hexdigest()[:16]}.json"
SESSION_FILE = os.path.join(_SESSION_DIR, _SESSION_FILENAME)
AUDIT_LOG = os.path.join(PLUGIN_DATA, "audit.jsonl")

# Allowed URL schemes for SENESCHAL endpoint (SSRF protection)
_ALLOWED_SCHEMES = {"https", "http"}
_LOOPBACK_HOSTS = {"127.0.0.1", "localhost", "::1", "[::1]"}

# ── Helpers ────────────────────────────────────────────────────────

def _load_json(path: str) -> dict:
    """Load a JSON file, return empty dict on failure."""
    try:
        with open(path) as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError):
        return {}


def _save_json_secure(path: str, data: dict) -> None:
    """Write JSON to file with restricted permissions and integrity HMAC."""
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    # Compute HMAC over content for tamper detection
    content = json.dumps(data, sort_keys=True)
    mac = _compute_hmac(content)
    wrapper = {"data": data, "hmac": mac}
    # Write atomically via tempfile to prevent TOCTOU
    fd, tmp_path = tempfile.mkstemp(
        dir=os.path.dirname(path), suffix=".tmp",
    )
    try:
        with os.fdopen(fd, "w") as f:
            json.dump(wrapper, f, indent=2)
        os.chmod(tmp_path, stat.S_IRUSR | stat.S_IWUSR)  # 0o600
        os.replace(tmp_path, path)
    except Exception:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        raise


def _load_json_secure(path: str) -> dict:
    """Load a JSON file with HMAC integrity verification."""
    try:
        with open(path) as f:
            wrapper = json.load(f)
    except (OSError, json.JSONDecodeError):
        return {}
    if not isinstance(wrapper, dict) or "data" not in wrapper:
        return {}
    data = wrapper["data"]
    stored_mac = wrapper.get("hmac", "")
    expected_mac = _compute_hmac(json.dumps(data, sort_keys=True))
    if not hmac.compare_digest(stored_mac, expected_mac):
        print("Session file integrity check failed — possible tampering", file=sys.stderr)
        return {}
    return data


def _compute_hmac(content: str) -> str:
    """Compute HMAC-SHA256 over content using session-bound key."""
    # Key derived from session ID + API key (if available) + plugin root
    key_material = f"{SESSION_ID}:{os.environ.get('SENESCHAL_API_KEY', '')}:{PLUGIN_ROOT}"
    key = hashlib.sha256(key_material.encode()).digest()
    return hmac.new(key, content.encode(), hashlib.sha256).hexdigest()


def _timestamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _audit_local(event: str, details: dict) -> None:
    """Append a JSONL audit record with chained HMAC for tamper evidence."""
    record = {
        "timestamp": _timestamp(),
        "event": event,
        "session_id": SESSION_ID,
        **details,
    }
    # Read previous record's hash for chaining
    prev_hash = "0" * 64
    try:
        with open(AUDIT_LOG, "rb") as f:
            # Seek to last line
            f.seek(0, 2)
            pos = f.tell()
            if pos > 0:
                # Read backwards to find last newline
                pos -= 1
                while pos > 0:
                    f.seek(pos)
                    if f.read(1) == b"\n":
                        break
                    pos -= 1
                last_line = f.read().decode().strip()
                if last_line:
                    try:
                        last_record = json.loads(last_line)
                        prev_hash = last_record.get("record_hash", prev_hash)
                    except json.JSONDecodeError:
                        pass
    except OSError:
        pass

    # Chain: hash of (previous_hash + current_record)
    record_json = json.dumps(record, sort_keys=True)
    chain_input = f"{prev_hash}:{record_json}"
    record["record_hash"] = hashlib.sha256(chain_input.encode()).hexdigest()

    os.makedirs(os.path.dirname(AUDIT_LOG) or ".", exist_ok=True)
    with open(AUDIT_LOG, "a") as f:
        f.write(json.dumps(record) + "\n")


def _http_request(url: str, data: dict | None = None, method: str = "GET",
                  api_key: str = "") -> dict | None:
    """Make an HTTP request to SENESCHAL. Returns parsed JSON or None."""
    headers = {"Content-Type": "application/json"}
    if api_key:
        headers["X-API-Key"] = api_key
    body = json.dumps(data).encode() if data else None
    req = Request(url, data=body, headers=headers, method=method)
    try:
        with urlopen(req, timeout=HTTP_TIMEOUT) as resp:
            return json.loads(resp.read().decode())
    except (URLError, OSError, json.JSONDecodeError, ValueError):
        return None


# ── Endpoint validation (SSRF protection) ─────────────────────────

def _validate_endpoint(url: str, fail_closed: bool = False) -> str | None:
    """Validate a SENESCHAL endpoint URL. Returns validated URL or None.

    Rejects: file://, gopher://, ftp://, non-loopback http:// in
    production mode (fail_closed=true implies production).
    """
    try:
        parsed = urlparse(url)
    except ValueError:
        return None

    if parsed.scheme not in _ALLOWED_SCHEMES:
        print(f"Rejected endpoint scheme: {parsed.scheme}://", file=sys.stderr)
        return None

    # In fail_closed (production) mode, require HTTPS for non-loopback
    hostname = parsed.hostname or ""
    if fail_closed and parsed.scheme == "http":
        if hostname not in _LOOPBACK_HOSTS:
            print(f"Rejected non-loopback HTTP endpoint in fail_closed mode: {hostname}", file=sys.stderr)
            return None

    # Block obvious internal network targets
    if hostname.endswith(".internal") or hostname.startswith("169.254."):
        print(f"Rejected internal network endpoint: {hostname}", file=sys.stderr)
        return None

    return url


# ── Discovery ──────────────────────────────────────────────────────

def _discover_endpoint(config: dict) -> str:
    """Discover the SENESCHAL endpoint from config or environment."""
    fail_closed = config.get("fail_closed", False)

    # Explicit endpoint in config
    if config.get("endpoint"):
        validated = _validate_endpoint(config["endpoint"], fail_closed)
        if validated:
            return validated

    # Discovery chain
    for source in config.get("endpoint_discovery", []):
        if source.startswith("env:"):
            val = os.environ.get(source[4:], "")
            if val:
                validated = _validate_endpoint(val, fail_closed)
                if validated:
                    return validated
        elif source.startswith("http"):
            validated = _validate_endpoint(source, fail_closed)
            if validated:
                return validated

    return "http://127.0.0.1:9700"


def _get_api_key(config: dict) -> str:
    """Get the SENESCHAL API key from environment."""
    env_var = config.get("api_key_env", "SENESCHAL_API_KEY")
    return os.environ.get(env_var, "")


# ── Session state ──────────────────────────────────────────────────

def _load_session() -> dict:
    return _load_json_secure(SESSION_FILE)


def _save_session(data: dict) -> None:
    _save_json_secure(SESSION_FILE, data)


# ── HITL gate matching ─────────────────────────────────────────────

# Synonym groups for HITL trigger expansion — catches rephrasing
_HITL_SYNONYMS: dict[str, list[str]] = {
    "bankroll": ["bankroll", "fund", "funds", "balance", "account balance", "wallet"],
    "allocation": ["allocation", "distribution", "apportionment", "assignment"],
    "wager": ["wager", "bet", "stake", "gamble", "risk"],
    "withdraw": ["withdraw", "withdrawal", "cash out", "cashout", "payout", "pay out"],
    "deposit": ["deposit", "fund", "top up", "top-up", "add funds"],
    "transfer": ["transfer", "send", "move funds", "wire"],
    "delete": ["delete", "remove", "erase", "destroy", "wipe", "purge"],
    "execute": ["execute", "run", "invoke", "trigger", "fire", "launch"],
    "payment": ["payment", "pay", "charge", "bill", "invoice", "transaction"],
}

def _expand_trigger(trigger: str) -> list[str]:
    """Expand a HITL trigger into synonym variants."""
    variants = [trigger]
    trigger_lower = trigger.lower()
    for root, synonyms in _HITL_SYNONYMS.items():
        if root in trigger_lower:
            for syn in synonyms:
                if syn != root:
                    variants.append(trigger_lower.replace(root, syn))
    return variants

def _hitl_matches(trigger: str, search_text: str) -> bool:
    """Check if a HITL trigger (or any synonym variant) matches."""
    for variant in _expand_trigger(trigger):
        if variant.lower() in search_text:
            return True
    return False


# ── Commands ───────────────────────────────────────────────────────

def cmd_register() -> int:
    """Register this plugin's agents with SENESCHAL on session start."""
    config = _load_json(os.path.join(CASTELLAN_DIR, "seneschal.json"))
    policy = _load_json(os.path.join(CASTELLAN_DIR, "policy.json"))
    spec_hash_path = os.path.join(CASTELLAN_DIR, "spec.hash")

    spec_hash = ""
    try:
        with open(spec_hash_path) as f:
            first_line = f.readline().strip()
            if first_line.startswith("SHA256:"):
                spec_hash = first_line[7:]
    except OSError:
        pass

    endpoint = _discover_endpoint(config)
    api_key = _get_api_key(config)
    fail_closed = config.get("fail_closed", False)

    # Check if SENESCHAL is reachable
    ping_url = f"{endpoint}/api/v1/ping"
    ping_result = _http_request(ping_url)

    if ping_result is None:
        # /api/v1/ping returns plain text "pong", not JSON —
        # _http_request will fail to parse it.  Try raw fetch.
        try:
            req = Request(ping_url)
            if api_key:
                req.add_header("X-API-Key", api_key)
            with urlopen(req, timeout=HTTP_TIMEOUT) as resp:
                body = resp.read().decode().strip()
                if body == "pong":
                    ping_result = {"status": "ok"}
        except (URLError, OSError):
            ping_result = None

    if ping_result is None:
        # SENESCHAL unreachable
        session = {
            "tier": 3 if fail_closed else 2,
            "endpoint": endpoint,
            "node_id": "",
            "registered": False,
            "fail_closed": fail_closed,
            "started_at": _timestamp(),
        }
        _save_session(session)
        _audit_local("session_start", {
            "seneschal": "unreachable",
            "tier": session["tier"],
            "fail_closed": fail_closed,
        })

        if fail_closed:
            print("SENESCHAL unreachable and fail_closed=true — blocking session", file=sys.stderr)
            return 1
        else:
            print("SENESCHAL unreachable — falling back to local enforcement", file=sys.stderr)
            return 0

    # SENESCHAL is reachable — register
    reg_config = config.get("node_registration", {})
    node_id = f"cowork-{reg_config.get('agent_name', 'unknown')}-{SESSION_ID[:8]}"

    # JWT verification derived from governance tier via seneschal.json
    require_jwt = config.get("require_jwt_verification", False)

    registration = {
        "node_id": node_id,
        "agent_name": reg_config.get("agent_name", ""),
        "spec_hash": spec_hash,
        "autonomy_level": reg_config.get("autonomy_level", 3),
        "risk_tier": reg_config.get("risk_tier", "LOW"),
        "capabilities": reg_config.get("capabilities", []),
        "framework": reg_config.get("framework", "cowork-plugin"),
        "policy": {
            "enabled": True,
            "can_discover_peers": False,
            "discoverable": True,
            "can_initiate": True,
            "can_receive": True,
            "require_jwt_verification": require_jwt,
            "require_checksum_match": True,
            "max_outbound_per_minute": 30,
            "max_inbound_per_minute": 30,
        },
    }

    reg_url = f"{endpoint}/api/v1/nodes/register"
    result = _http_request(reg_url, registration, method="POST", api_key=api_key)

    if result is None or "error" in (result or {}):
        error_msg = (result or {}).get("error", {}).get("message", "unknown error")
        session = {
            "tier": 3 if fail_closed else 2,
            "endpoint": endpoint,
            "node_id": "",
            "registered": False,
            "fail_closed": fail_closed,
            "error": error_msg,
            "started_at": _timestamp(),
        }
        _save_session(session)

        if fail_closed:
            print(f"SENESCHAL registration failed: {error_msg} — blocking (fail_closed)", file=sys.stderr)
            return 1
        return 0

    # Registered successfully — Tier 1
    session = {
        "tier": 1,
        "endpoint": endpoint,
        "api_key_env": config.get("api_key_env", "SENESCHAL_API_KEY"),
        "node_id": node_id,
        "registered": True,
        "fail_closed": fail_closed,
        "started_at": _timestamp(),
    }
    _save_session(session)
    _audit_local("session_start", {
        "seneschal": "registered",
        "tier": 1,
        "node_id": node_id,
        "endpoint": endpoint,
    })
    return 0


def cmd_check(tool_name: str, tool_input: str) -> int:
    """Check if a tool call is allowed. Exit 1 to block."""
    session = _load_session()
    tier = session.get("tier", 2)
    policy = _load_json(os.path.join(CASTELLAN_DIR, "policy.json"))
    hitl_gates = _load_json(os.path.join(CASTELLAN_DIR, "hitl_gates.json"))

    # ── HITL gate check (applies at all tiers) ──
    # Extract searchable text from tool_input: if it's JSON, pull string
    # values only (avoids false positives from JSON keys/structure).
    search_text = tool_input.lower()
    try:
        parsed = json.loads(tool_input)
        if isinstance(parsed, dict):
            search_text = " ".join(
                str(v).lower() for v in parsed.values() if isinstance(v, (str, int, float))
            )
    except (json.JSONDecodeError, ValueError):
        pass  # not JSON — match against raw string

    for gate in hitl_gates.get("gates", []):
        trigger = gate.get("trigger", "")
        if trigger and _hitl_matches(trigger, search_text):
            _audit_local("hitl_gate_triggered", {
                "tool": tool_name,
                "trigger": gate["trigger"],
                "action": gate.get("action", "block"),
            })
            print(f"HITL gate: {gate.get('trigger')} — requires explicit approval", file=sys.stderr)
            return 1

    # ── Tier 3: fail closed ──
    if tier == 3:
        _audit_local("tool_blocked", {"tool": tool_name, "reason": "fail_closed"})
        print(f"SENESCHAL unreachable (fail_closed) — blocking {tool_name}", file=sys.stderr)
        return 1

    # ── Tier 2: local policy enforcement ──
    if tier == 2:
        tool_policy = policy.get("tool_policy", {})
        denied = tool_policy.get("denied", [])
        if tool_name in denied:
            _audit_local("tool_blocked", {"tool": tool_name, "reason": "denied_by_policy"})
            print(f"Policy denied: {tool_name}", file=sys.stderr)
            return 1
        _audit_local("tool_allowed", {"tool": tool_name, "tier": 2})
        return 0

    # ── Tier 1: SENESCHAL enforcement ──
    endpoint = session.get("endpoint", "")
    node_id = session.get("node_id", "")
    api_key = os.environ.get(session.get("api_key_env", "SENESCHAL_API_KEY"), "")

    check_url = f"{endpoint}/api/v1/mcp/check"
    check_body = {
        "agent_id": node_id,
        "server_id": "claude-code-runtime",
        "tool_name": tool_name,
    }

    result = _http_request(check_url, check_body, method="POST", api_key=api_key)

    if result is None:
        # SENESCHAL became unreachable mid-session — degrade
        fail_closed = session.get("fail_closed", False)
        new_tier = 3 if fail_closed else 2
        session["tier"] = new_tier
        _save_session(session)
        _audit_local("seneschal_degraded", {"from_tier": 1, "to_tier": new_tier})

        if fail_closed:
            print(f"SENESCHAL unreachable mid-session (fail_closed) — blocking {tool_name}", file=sys.stderr)
            return 1
        # Re-run at Tier 2
        return cmd_check(tool_name, tool_input)

    allowed = result.get("allowed", False)
    reason = result.get("reason", "")

    _audit_local("tool_check", {
        "tool": tool_name,
        "allowed": allowed,
        "reason": reason,
        "violation_type": result.get("violation_type", ""),
        "tier": 1,
    })

    if not allowed:
        print(f"SENESCHAL denied {tool_name}: {reason}", file=sys.stderr)
        return 1

    return 0


def cmd_check_delegation(agent_name: str) -> int:
    """Check if a delegation to a sub-agent is allowed."""
    session = _load_session()
    policy = _load_json(os.path.join(CASTELLAN_DIR, "policy.json"))

    limits = policy.get("interaction_limits", {})
    max_delegations = limits.get("max_delegations", 3)

    # Track delegation count in session
    count = session.get("delegation_count", 0)
    if count >= max_delegations:
        _audit_local("delegation_blocked", {
            "agent": agent_name,
            "reason": f"max_delegations ({max_delegations}) exceeded",
            "count": count,
        })
        print(f"Delegation limit reached ({count}/{max_delegations})", file=sys.stderr)
        return 1

    session["delegation_count"] = count + 1
    _save_session(session)
    _audit_local("delegation_allowed", {"agent": agent_name, "count": count + 1})
    return 0


def cmd_audit(tool_name: str = "", event: str = "", agent_name: str = "") -> int:
    """Log an audit event to SENESCHAL or local fallback."""
    session = _load_session()
    tier = session.get("tier", 2)

    details = {
        "tool": tool_name,
        "event": event,
        "agent": agent_name,
    }

    if tier == 1:
        endpoint = session.get("endpoint", "")
        node_id = session.get("node_id", "")
        api_key = os.environ.get(session.get("api_key_env", "SENESCHAL_API_KEY"), "")

        append_url = f"{endpoint}/api/v1/chain/append"
        record = {
            "event_type": event or "tool_call_allowed",
            "node_id": node_id,
            "details": json.dumps(details),
            "spec_hash": session.get("spec_hash", ""),
        }
        _http_request(append_url, record, method="POST", api_key=api_key)

    # Always log locally as backup
    _audit_local(event or "audit", details)
    return 0


def cmd_deregister() -> int:
    """Deregister from SENESCHAL on session end."""
    session = _load_session()
    tier = session.get("tier", 2)

    if tier == 1 and session.get("registered"):
        endpoint = session.get("endpoint", "")
        node_id = session.get("node_id", "")
        api_key = os.environ.get(session.get("api_key_env", "SENESCHAL_API_KEY"), "")

        dereg_url = f"{endpoint}/api/v1/nodes/{node_id}"
        _http_request(dereg_url, method="DELETE", api_key=api_key)

    _audit_local("session_end", {
        "tier": tier,
        "node_id": session.get("node_id", ""),
    })

    # Clean up session file
    try:
        os.remove(SESSION_FILE)
    except OSError:
        pass

    return 0


# ── CLI dispatch ───────────────────────────────────────────────────

def main() -> int:
    args = sys.argv[1:]
    if not args:
        print("Usage: seneschal-gate.py <register|check|check-delegation|audit|deregister>", file=sys.stderr)
        return 1

    cmd = args[0]

    if cmd == "register":
        return cmd_register()

    elif cmd == "check":
        tool_name = ""
        tool_input = ""
        i = 1
        while i < len(args):
            if args[i] == "--tool" and i + 1 < len(args):
                tool_name = args[i + 1]
                i += 2
            elif args[i] == "--input-stdin":
                i += 1
            else:
                i += 1
        # Always read tool input from stdin to prevent shell injection
        if not sys.stdin.isatty():
            tool_input = sys.stdin.read()
        return cmd_check(tool_name, tool_input)

    elif cmd == "check-delegation":
        agent_name = ""
        i = 1
        while i < len(args):
            if args[i] == "--agent" and i + 1 < len(args):
                agent_name = args[i + 1]
                i += 2
            else:
                i += 1
        return cmd_check_delegation(agent_name)

    elif cmd == "audit":
        tool_name = ""
        event = ""
        agent_name = ""
        i = 1
        while i < len(args):
            if args[i] == "--tool" and i + 1 < len(args):
                tool_name = args[i + 1]
                i += 2
            elif args[i] == "--event" and i + 1 < len(args):
                event = args[i + 1]
                i += 2
            elif args[i] == "--agent" and i + 1 < len(args):
                agent_name = args[i + 1]
                i += 2
            else:
                i += 1
        return cmd_audit(tool_name, event, agent_name)

    elif cmd == "deregister":
        return cmd_deregister()

    else:
        print(f"Unknown command: {cmd}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())

